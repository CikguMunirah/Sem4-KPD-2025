CREATE DATABASE IF NOT EXISTS db_makmal;
USE db_makmal;

DROP TABLE IF EXISTS senarai_tempahan;
CREATE TABLE senarai_tempahan (
  id_tempah VARCHAR(6) PRIMARY KEY,
  nama_pensyarah VARCHAR(80) NOT NULL,
  subjek VARCHAR(100) NOT NULL,
  tarikh_tempah DATE NOT NULL,
  masa_mula TIME NOT NULL,
  masa_akhir TIME NOT NULL
);

INSERT INTO senarai_tempahan VALUES
('M001','Cikgu Dina','Asas Pengaturcaraan','2024-10-15','09:00','11:00'),
('M039','Encik Izzat','Multimedia','2024-10-18','14:00','16:00'),
('M102','Puan Amira','Sistem Maklumat','2024-10-20','10:00','12:00');
