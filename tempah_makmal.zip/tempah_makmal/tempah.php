<?php include 'config.php'; ?>
<?php
// TODO: Jika butang hantar ditekan, buat INSERT ke dalam jadual
// mysqli_query($connect,"INSERT INTO ...");

?>
<!DOCTYPE html><html><body>
<h3>Tambah Tempahan</h3>

<form method="post">
ID Tempah: <input name="id_tempah"><br><br>
Nama Pensyarah: <input name="nama_pensyarah"><br><br>
Subjek: <input name="subjek"><br><br>
Tarikh Tempah: <input type="date" name="tarikh_tempah"><br><br>
Masa Mula: <input type="time" name="masa_mula"><br><br>
Masa Akhir: <input type="time" name="masa_akhir"><br><br>

<button name="hantar">Hantar</button>
</form><br>

<!-- TODO: Link kembali ke index.php -->
</body></html>