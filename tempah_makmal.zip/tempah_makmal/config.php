<?php
// TODO: Tetapkan hostname
$hostname = /* TODO */;
// TODO: Tetapkan username
$username = /* TODO */;
// TODO: Tetapkan password
$password = /* TODO */;
// TODO: Tetapkan nama database db_makmal
$database = /* TODO */;

$connect = /* TODO: mysqli_connect(...) */;

if(!$connect){
  die('DB Failed');
}

echo 'sambungan berjaya';
?>