<?php
include 'config.php';
// TODO: dapatkan id_tempah dari URL dan padam rekod
// mysqli_query(...);
header('Location:index.php');
?>