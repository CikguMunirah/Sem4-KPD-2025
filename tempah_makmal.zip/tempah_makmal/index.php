<?php include 'config.php'; ?>
<!DOCTYPE html><html><body>
<h3>SISTEM TEMPAHAN MAKMAL</h3>
<!-- TODO: Tambah link ke tambah rekod -->
<a href="tempah.php">+ Tempahan Baharu</a>

<table border="1" cellpadding="5">
<tr>
  <th>ID</th>
  <th>Pensyarah</th>
  <th>Subjek</th>
  <th>Tarikh</th>
  <th>Mula</th>
  <th>Akhir</th>
  <th>Catatan</th>
</tr>

<?php
// TODO: Papar rekod SELECT * ORDER BY tarikh_tempah ASC
?>
</table>

</body></html>